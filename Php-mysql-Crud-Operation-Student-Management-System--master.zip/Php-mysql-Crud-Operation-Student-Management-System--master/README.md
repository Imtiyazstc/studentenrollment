# Php-mysql-Crud-Operation-Student-Management-System-
This is Simple student management system build in php and mysql ,its application take all the operation like create ,view,delete,update the record.



https://basicandroidprogram.blogspot.com/
