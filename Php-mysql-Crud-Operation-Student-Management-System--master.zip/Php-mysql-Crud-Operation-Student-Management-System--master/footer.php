<footer class="container-fluid text-center">
  <p>@Codeenable.com</p>
</footer>

</body>
</html>